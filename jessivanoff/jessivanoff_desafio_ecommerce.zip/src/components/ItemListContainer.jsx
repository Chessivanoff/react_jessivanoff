const ItemListContainer = ( {greeting} ) => {
return (
        <div style={{color:'darkred', fontSize: 24, textAlign: "center", paddingTop: "50px", paddingBottom: "50px"}}>Hola Usuario,  {greeting} </div>
        )
}
export default ItemListContainer
    